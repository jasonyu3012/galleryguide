--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.7 (Ubuntu 14.7-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.7 (Ubuntu 14.7-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE ggdb;
--
-- Name: ggdb; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE ggdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C.UTF-8';


ALTER DATABASE ggdb OWNER TO postgres;

\connect ggdb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: artist; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public.artist (
    id integer NOT NULL,
    name character varying NOT NULL,
    biography character varying NOT NULL,
    birth_year integer NOT NULL,
    death_year integer,
    thumbnail character varying NOT NULL,
    num_artworks integer NOT NULL,
    num_galleries integer NOT NULL
);


ALTER TABLE public.artist OWNER TO ubuntu;

--
-- Name: artist artwork relationship; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public."artist artwork relationship" (
    artist_id integer NOT NULL,
    artwork_id integer NOT NULL
);


ALTER TABLE public."artist artwork relationship" OWNER TO ubuntu;

--
-- Name: artist_id_seq; Type: SEQUENCE; Schema: public; Owner: ubuntu
--

CREATE SEQUENCE public.artist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.artist_id_seq OWNER TO ubuntu;

--
-- Name: artist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ubuntu
--

ALTER SEQUENCE public.artist_id_seq OWNED BY public.artist.id;


--
-- Name: artwork; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public.artwork (
    id integer NOT NULL,
    artist_id integer NOT NULL,
    gallery_id integer NOT NULL,
    title character varying NOT NULL,
    date character varying NOT NULL,
    medium character varying NOT NULL,
    iconicity double precision NOT NULL,
    image_rights character varying NOT NULL,
    image character varying NOT NULL
);


ALTER TABLE public.artwork OWNER TO ubuntu;

--
-- Name: artwork_id_seq; Type: SEQUENCE; Schema: public; Owner: ubuntu
--

CREATE SEQUENCE public.artwork_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.artwork_id_seq OWNER TO ubuntu;

--
-- Name: artwork_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ubuntu
--

ALTER SEQUENCE public.artwork_id_seq OWNED BY public.artwork.id;


--
-- Name: gallery; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public.gallery (
    id integer NOT NULL,
    name character varying NOT NULL,
    region character varying NOT NULL,
    description character varying NOT NULL,
    thumbnail character varying NOT NULL,
    website character varying NOT NULL,
    num_artworks integer NOT NULL,
    num_artists integer NOT NULL
);


ALTER TABLE public.gallery OWNER TO ubuntu;

--
-- Name: gallery artist relationship; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public."gallery artist relationship" (
    gallery_id integer NOT NULL,
    artist_id integer NOT NULL
);


ALTER TABLE public."gallery artist relationship" OWNER TO ubuntu;

--
-- Name: gallery artwork relationship; Type: TABLE; Schema: public; Owner: ubuntu
--

CREATE TABLE public."gallery artwork relationship" (
    gallery_id integer NOT NULL,
    artwork_id integer NOT NULL
);


ALTER TABLE public."gallery artwork relationship" OWNER TO ubuntu;

--
-- Name: gallery_id_seq; Type: SEQUENCE; Schema: public; Owner: ubuntu
--

CREATE SEQUENCE public.gallery_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gallery_id_seq OWNER TO ubuntu;

--
-- Name: gallery_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ubuntu
--

ALTER SEQUENCE public.gallery_id_seq OWNED BY public.gallery.id;


--
-- Name: artist id; Type: DEFAULT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.artist ALTER COLUMN id SET DEFAULT nextval('public.artist_id_seq'::regclass);


--
-- Name: artwork id; Type: DEFAULT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.artwork ALTER COLUMN id SET DEFAULT nextval('public.artwork_id_seq'::regclass);


--
-- Name: gallery id; Type: DEFAULT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.gallery ALTER COLUMN id SET DEFAULT nextval('public.gallery_id_seq'::regclass);


--
-- Data for Name: artist; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public.artist (id, name, biography, birth_year, death_year, thumbnail, num_artworks, num_galleries) FROM stdin;
\.
COPY public.artist (id, name, biography, birth_year, death_year, thumbnail, num_artworks, num_galleries) FROM '$$PATH$$/3350.dat';

--
-- Data for Name: artist artwork relationship; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public."artist artwork relationship" (artist_id, artwork_id) FROM stdin;
\.
COPY public."artist artwork relationship" (artist_id, artwork_id) FROM '$$PATH$$/3355.dat';

--
-- Data for Name: artwork; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public.artwork (id, artist_id, gallery_id, title, date, medium, iconicity, image_rights, image) FROM stdin;
\.
COPY public.artwork (id, artist_id, gallery_id, title, date, medium, iconicity, image_rights, image) FROM '$$PATH$$/3352.dat';

--
-- Data for Name: gallery; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public.gallery (id, name, region, description, thumbnail, website, num_artworks, num_artists) FROM stdin;
\.
COPY public.gallery (id, name, region, description, thumbnail, website, num_artworks, num_artists) FROM '$$PATH$$/3348.dat';

--
-- Data for Name: gallery artist relationship; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public."gallery artist relationship" (gallery_id, artist_id) FROM stdin;
\.
COPY public."gallery artist relationship" (gallery_id, artist_id) FROM '$$PATH$$/3353.dat';

--
-- Data for Name: gallery artwork relationship; Type: TABLE DATA; Schema: public; Owner: ubuntu
--

COPY public."gallery artwork relationship" (gallery_id, artwork_id) FROM stdin;
\.
COPY public."gallery artwork relationship" (gallery_id, artwork_id) FROM '$$PATH$$/3354.dat';

--
-- Name: artist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ubuntu
--

SELECT pg_catalog.setval('public.artist_id_seq', 708, true);


--
-- Name: artwork_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ubuntu
--

SELECT pg_catalog.setval('public.artwork_id_seq', 7986, true);


--
-- Name: gallery_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ubuntu
--

SELECT pg_catalog.setval('public.gallery_id_seq', 10, true);


--
-- Name: artist artist_name_key; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.artist
    ADD CONSTRAINT artist_name_key UNIQUE (name);


--
-- Name: artist artist_pkey; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.artist
    ADD CONSTRAINT artist_pkey PRIMARY KEY (id);


--
-- Name: artwork artwork_pkey; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.artwork
    ADD CONSTRAINT artwork_pkey PRIMARY KEY (id);


--
-- Name: artwork artwork_title_key; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.artwork
    ADD CONSTRAINT artwork_title_key UNIQUE (title);


--
-- Name: gallery gallery_name_key; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.gallery
    ADD CONSTRAINT gallery_name_key UNIQUE (name);


--
-- Name: gallery gallery_pkey; Type: CONSTRAINT; Schema: public; Owner: ubuntu
--

ALTER TABLE ONLY public.gallery
    ADD CONSTRAINT gallery_pkey PRIMARY KEY (id);


--
-- Name: DATABASE ggdb; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON DATABASE ggdb TO ubuntu;


--
-- PostgreSQL database dump complete
--

